package com.example.weighttrackerapp;

import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    ArrayList<String> dataList;
    DBHelper db;

    public RecyclerViewAdapter(ArrayList<String> dataList, DBHelper db) {
        this.dataList = dataList;
        this.db = db;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemText;
        Button deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            itemText = itemView.findViewById(R.id.itemText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        String item = dataList.get(position);
        holder.itemText.setText(item);

        holder.deleteButton.setOnClickListener(v -> {

            // Extract ID from string (ID:1 | 180 lbs | date)
            int id = Integer.parseInt(item.split("\\|")[0].replace("ID:", "").trim());

            db.deleteWeight(id);

            dataList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, dataList.size());
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}