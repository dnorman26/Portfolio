package com.example.weighttrackerapp;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import android.database.Cursor;
import java.util.ArrayList;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;

public class DashboardActivity extends AppCompatActivity {

    EditText weightInput, dateInput;
    Button addButton;
    RecyclerView recyclerView;

    TextView goalText, currentText, diffText;

    DBHelper db;
    ArrayList<String> dataList;
    RecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        weightInput = findViewById(R.id.weightInput);
        dateInput = findViewById(R.id.dateInput);
        addButton = findViewById(R.id.addButton);
        recyclerView = findViewById(R.id.recyclerView);


        goalText = findViewById(R.id.goalWeight);
        currentText = findViewById(R.id.currentWeight);
        diffText = findViewById(R.id.awayFromGoal);

        db = new DBHelper(this);
        dataList = new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerViewAdapter(dataList, db);
        recyclerView.setAdapter(adapter);

        loadData();

        addButton.setOnClickListener(v -> {

            String w = weightInput.getText().toString();
            String d = dateInput.getText().toString();

            if (w.isEmpty() || d.isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            db.insertWeight(Double.parseDouble(w), d);
            loadData();
        });
    }

    private void loadData() {

        Cursor cursor = db.getWeights();
        dataList.clear();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            double weight = cursor.getDouble(1);
            String date = cursor.getString(2);

            dataList.add("ID:" + id + " | " + weight + " lbs | " + date);
        }

        cursor.close();
        adapter.notifyDataSetChanged();


        updateGoalDisplay();
    }


    private void updateGoalDisplay() {

        float goal = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                .getFloat("goalWeight", 0);

        if (goal == 0) {
            goalText.setText("Goal: --");
            return;
        }

        goalText.setText("Goal: " + goal + " lbs");

        Cursor cursor = db.getWeights();

        if (cursor.moveToLast()) {
            double current = cursor.getDouble(1);

            currentText.setText("Current: " + current + " lbs");

            double diff = current - goal;

            diffText.setText(Math.abs(diff) + " lbs " + "to go.");
        }

        cursor.close();
    }

    // MENU
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_sms) {
            startActivity(new Intent(this, SmsActivity.class));
            return true;
        }

        if (item.getItemId() == R.id.menu_goal) {
            startActivity(new Intent(this, GoalActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}