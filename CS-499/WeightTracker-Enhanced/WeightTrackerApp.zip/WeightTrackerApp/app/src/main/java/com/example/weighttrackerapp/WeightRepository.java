package com.example.weighttrackerapp;

import android.content.Context;
import android.database.Cursor;
import java.util.ArrayList;

public class WeightRepository {

    private DBHelper db;

    public WeightRepository(Context context) {
        db = new DBHelper(context);
    }

    public void insertWeight(double weight, String date) {
        db.insertWeight(weight, date);
    }

    public void updateWeight(int id, double weight, String date) {
        db.updateWeight(id, weight, date);
    }

    public void deleteWeight(int id) {
        db.deleteWeight(id);
    }

    public ArrayList<WeightEntry> getAllWeights() {
        ArrayList<WeightEntry> list = new ArrayList<>();
        Cursor cursor = db.getWeights();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            double weight = cursor.getDouble(1);
            String date = cursor.getString(2);
            list.add(new WeightEntry(id, weight, date));
        }

        cursor.close();
        return list;
    }

    public DBHelper getDb() {
        return db;
    }
}

