package com.example.weighttrackerapp;

public class WeeklySummary {
    public String week;
    public double average;

    public WeeklySummary(String week, double average) {
        this.week = week;
        this.average = average;
    }
}
