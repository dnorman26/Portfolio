package com.example.weighttrackerapp;

import android.content.Context;
import android.database.sqlite.*;
import android.content.ContentValues;
import android.database.Cursor;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "WeightDB", null, 3);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT, " +
                        "password TEXT)"
        );

        createWeightsTable(db);
    }

    private void createWeightsTable(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE weights (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "weight REAL CHECK(weight > 0 AND weight < 1000), " +
                        "date TEXT NOT NULL CHECK(" +
                        "length(date) = 10 AND " +
                        "date GLOB '[0-1][0-9]-[0-3][0-9]-[0-9][0-9][0-9][0-9]' AND " +
                        "substr(date, 1, 2) BETWEEN '01' AND '12' AND " +
                        "substr(date, 4, 2) BETWEEN '01' AND '31'" +
                        "))"
        );

        db.execSQL(
                "CREATE INDEX idx_weights_date ON weights(date)"
        );

        db.execSQL(
                "CREATE INDEX idx_weights_weight ON weights(weight)"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 3) {
            db.execSQL(
                    "CREATE TABLE weights_new (" +
                            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "weight REAL CHECK(weight > 0 AND weight < 1000), " +
                            "date TEXT NOT NULL CHECK(" +
                            "length(date) = 10 AND " +
                            "date GLOB '[0-1][0-9]-[0-3][0-9]-[0-9][0-9][0-9][0-9]' AND " +
                            "substr(date, 1, 2) BETWEEN '01' AND '12' AND " +
                            "substr(date, 4, 2) BETWEEN '01' AND '31'" +
                            "))"
            );

            db.execSQL(
                    "INSERT INTO weights_new (id, weight, date) " +
                            "SELECT id, weight, date FROM weights " +
                            "WHERE weight > 0 AND weight < 1000 " +
                            "AND date IS NOT NULL " +
                            "AND length(date) = 10 " +
                            "AND date GLOB '[0-1][0-9]-[0-3][0-9]-[0-9][0-9][0-9][0-9]' " +
                            "AND substr(date, 1, 2) BETWEEN '01' AND '12' " +
                            "AND substr(date, 4, 2) BETWEEN '01' AND '31'"
            );

            db.execSQL("DROP TABLE weights");
            db.execSQL("ALTER TABLE weights_new RENAME TO weights");

            db.execSQL(
                    "CREATE INDEX idx_weights_date ON weights(date)"
            );

            db.execSQL(
                    "CREATE INDEX idx_weights_weight ON weights(weight)"
            );
        }
    }

    private boolean isValidDate(String date) {
        if (date == null) {
            return false;
        }

        SimpleDateFormat format =
                new SimpleDateFormat("MM-dd-yyyy", Locale.US);

        format.setLenient(false);

        ParsePosition position = new ParsePosition(0);
        java.util.Date parsedDate = format.parse(date, position);

        return parsedDate != null
                && position.getIndex() == date.length();
    }

    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);

        return db.insert("users", null, cv) != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{username, password})) {

            return cursor.moveToFirst();
        }
    }

    public boolean insertWeight(double weight, String date) {
        if (!isValidDate(date) || weight <= 0 || weight >= 1000) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("weight", weight);
        cv.put("date", date);

        return db.insert("weights", null, cv) != -1;
    }

    public Cursor getWeights() {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery("SELECT * FROM weights", null);
    }

    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(
                "weights",
                "id=?",
                new String[]{String.valueOf(id)}
        );
    }

    public void updateWeight(int id, double weight, String date) {
        if (!isValidDate(date) || weight <= 0 || weight >= 1000) {
            return;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("weight", weight);
        values.put("date", date);

        db.update(
                "weights",
                values,
                "id=?",
                new String[]{String.valueOf(id)}
        );
    }
}

