package com.example.weighttrackerapp;

import android.view.*;
import android.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    ArrayList<WeightEntry> dataList;
    DBHelper db;

    public RecyclerViewAdapter(ArrayList<WeightEntry> dataList, DBHelper db) {
        this.dataList = dataList;
        this.db = db;
    }

    public void updateData(ArrayList<WeightEntry> newData) {
        this.dataList = newData;
        notifyDataSetChanged();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemText;
        Button deleteButton;
        Button editButton;

        public ViewHolder(View itemView) {
            super(itemView);
            itemText = itemView.findViewById(R.id.itemText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton = itemView.findViewById(R.id.editButton);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        WeightEntry entry = dataList.get(position);
        holder.itemText.setText("ID:" + entry.id + " | " + entry.weight + " lbs | " + entry.date);


        holder.deleteButton.setOnClickListener(v -> {

            int id = entry.id;

            db.deleteWeight(id);

            dataList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, dataList.size());
        });

        holder.editButton.setOnClickListener(v -> {

            WeightEntry updated = dataList.get(position);

            EditWeightDialog dialog = new EditWeightDialog(
                    holder.itemView.getContext(),
                    entry,
                    updatedEntry -> {
                        db.updateWeight(updatedEntry.id, updatedEntry.weight, updatedEntry.date);
                        dataList.set(position, updatedEntry);
                        notifyItemChanged(position);
                    }
            );

            dialog.show();
        });

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}


