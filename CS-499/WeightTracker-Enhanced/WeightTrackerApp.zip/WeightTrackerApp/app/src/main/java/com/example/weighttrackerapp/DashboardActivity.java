package com.example.weighttrackerapp;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import android.database.Cursor;
import java.util.ArrayList;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.View;
import android.widget.AdapterView;


public class DashboardActivity extends AppCompatActivity {

    WeightRepository repo;
    EditText weightInput, dateInput;
    Button addButton;
    RecyclerView recyclerView;

    TextView goalText, currentText, diffText;

    DBHelper db;
    ArrayList<WeightEntry> dataList;
    ArrayList<WeightEntry> fullList = new ArrayList<>();

    RecyclerViewAdapter adapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        weightInput = findViewById(R.id.weightInput);
        dateInput = findViewById(R.id.dateInput);

        dateInput.addTextChangedListener(new TextWatcher() {
            private boolean isEditing;

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isEditing) return;
                isEditing = true;

                String digits = s.toString().replaceAll("[^\\d]", "");
                StringBuilder formatted = new StringBuilder();

                for (int i = 0; i < digits.length() && i < 8; i++) {
                    formatted.append(digits.charAt(i));
                    if ((i == 1 || i == 3) && i != digits.length() - 1) {
                        formatted.append("-");
                    }
                }

                String newText = formatted.toString();
                if (!newText.equals(s.toString())) {
                    s.replace(0, s.length(), newText);
                }

                isEditing = false;
            }
        });


        addButton = findViewById(R.id.addButton);
        recyclerView = findViewById(R.id.recyclerView);


        goalText = findViewById(R.id.goalWeight);
        currentText = findViewById(R.id.currentWeight);
        diffText = findViewById(R.id.awayFromGoal);

        repo = new WeightRepository(this);
        db = repo.getDb();
        dataList = new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecyclerViewAdapter(dataList, db);
        recyclerView.setAdapter(adapter);

        loadData();

        WeightLogic logic = new WeightLogic();

        Spinner spinnerSort = findViewById(R.id.spinnerSort);
        Spinner spinnerFilter = findViewById(R.id.spinnerFilter);

        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String sortType = parent.getItemAtPosition(position).toString();
                dataList = new ArrayList<>(logic.sortWeights(dataList, sortType));
                adapter.updateData(dataList);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });



        spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String filterType = parent.getItemAtPosition(position).toString();
                dataList = new ArrayList<>(logic.filterWeights(fullList, filterType));
                adapter.updateData(dataList);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });


        addButton.setOnClickListener(v -> {

            String w = weightInput.getText().toString();
            String d = dateInput.getText().toString();

            if (w.isEmpty() || d.isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!d.matches("\\d{2}-\\d{2}-\\d{4}")) {
                Toast.makeText(this, "Use format MM-DD-YYYY", Toast.LENGTH_SHORT).show();
                return;
            }

            db.insertWeight(Double.parseDouble(w), d);
            loadData();
        });
    }

    private void loadData() {

        Cursor cursor = db.getWeights();
        fullList.clear();
        dataList.clear();

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            double weight = cursor.getDouble(1);
            String date = cursor.getString(2);

            WeightEntry entry = new WeightEntry(id, weight, date);
            fullList.add(entry);
            dataList.add(entry);
        }

        cursor.close();
        adapter.updateData(dataList);

        updateGoalDisplay();
    }



    private void updateGoalDisplay() {

        float goal = getSharedPreferences("AppPrefs", MODE_PRIVATE)
                .getFloat("goalWeight", 0);

        if (goal == 0) {
            goalText.setText("Goal: --");
            return;
        }

        goalText.setText("Goal: " + goal + " lbs");

        Cursor cursor = db.getWeights();

        if (cursor.moveToLast()) {
            double current = cursor.getDouble(1);

            currentText.setText("Current: " + current + " lbs");

            double diff = current - goal;

            diffText.setText(Math.abs(diff) + " lbs " + "to go.");
        }

        cursor.close();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_sms) {
            startActivity(new Intent(this, SmsActivity.class));
            return true;
        }

        if (item.getItemId() == R.id.menu_goal) {
            startActivity(new Intent(this, GoalActivity.class));
            return true;
        }

        if (item.getItemId() == R.id.menu_summary) {
            startActivity(new Intent(this, WeeklySummaryActivity.class));
            return true;
        }


        return super.onOptionsItemSelected(item);
    }

}