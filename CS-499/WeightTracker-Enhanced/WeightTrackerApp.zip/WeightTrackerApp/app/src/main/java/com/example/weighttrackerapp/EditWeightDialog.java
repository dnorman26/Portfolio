package com.example.weighttrackerapp;

import android.app.Dialog;
import android.content.Context;
import android.widget.*;

public class EditWeightDialog extends Dialog {

    public EditWeightDialog(Context context, WeightEntry entry, OnWeightUpdated callback) {
        super(context);
        setContentView(R.layout.dialog_edit_weight);

        EditText weightInput = findViewById(R.id.editWeightInput);
        EditText dateInput = findViewById(R.id.editDateInput);
        Button saveButton = findViewById(R.id.saveEditButton);

        weightInput.setText(String.valueOf(entry.weight));
        dateInput.setText(entry.date);

        saveButton.setOnClickListener(v -> {
            double newWeight = Double.parseDouble(weightInput.getText().toString());
            String newDate = dateInput.getText().toString();

            WeightEntry updated = new WeightEntry(entry.id, newWeight, newDate);
            callback.onUpdated(updated);
            dismiss();
        });
    }

    public interface OnWeightUpdated {
        void onUpdated(WeightEntry updatedEntry);
    }
}
