package com.example.weighttrackerapp;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;

public class SmsActivity extends AppCompatActivity {

    Button allowSmsButton;
    TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        allowSmsButton = findViewById(R.id.allowSmsButton);
        status = findViewById(R.id.statusText);

        allowSmsButton.setOnClickListener(v -> {

            if (checkSelfPermission(Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);

            } else {
                sendSMS();
            }
        });
    }

    private void sendSMS() {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage("1234567890", null,
                "Weight alert triggered!", null, null);

        status.setText("SMS Sent");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {

        if (grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            sendSMS();
        } else {
            status.setText("Permission denied");
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_dashboard) {
            startActivity(new Intent(this, DashboardActivity.class));
            return true;
        }

        if (item.getItemId() == R.id.menu_goal) {
            startActivity(new Intent(this, GoalActivity.class));
            return true;
        }
        if (item.getItemId() == R.id.menu_summary) {
            startActivity(new Intent(this, WeeklySummaryActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}