package com.example.weighttrackerapp;

import java.util.*;

public class WeightLogic {

    public List<WeeklySummary> calculateWeeklyAverages(List<WeightEntry> entries) {

        Map<String, List<Double>> weeklyMap = new HashMap<>();

        for (WeightEntry e : entries) {

            Date date = parseDate(e.date);

            if (date == null) {
                continue;
            }

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            int year = calendar.get(Calendar.YEAR);
            int week = calendar.get(Calendar.WEEK_OF_YEAR);

            String weekKey = year + "-W" + week;

            if (!weeklyMap.containsKey(weekKey)) {
                weeklyMap.put(weekKey, new ArrayList<>());
            }

            weeklyMap.get(weekKey).add(e.weight);
        }

        List<WeeklySummary> summaries = new ArrayList<>();

        for (String week : weeklyMap.keySet()) {

            List<Double> weights = weeklyMap.get(week);

            double total = 0;

            for (double weight : weights) {
                total += weight;
            }

            double average = total / weights.size();

            summaries.add(
                    new WeeklySummary(week, average)
            );
        }

        return summaries;
    }

    public List<WeeklySummary> sortSummaries(List<WeeklySummary> list, String type) {

        switch (type) {
            case "highest":
                list.sort((a, b) -> Double.compare(b.average, a.average));
                break;
            case "lowest":
                list.sort((a, b) -> Double.compare(a.average, b.average));
                break;
            case "recent":
                list.sort((a, b) -> b.week.compareTo(a.week));
                break;
            case "oldest":
                list.sort((a, b) -> a.week.compareTo(b.week));
                break;
        }

        return list;
    }
    public Date parseDate(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) return null;

        String[] formats = {"MM-dd-yyyy"};
        for (String f : formats) {
            try {
                return new java.text.SimpleDateFormat(f).parse(dateStr);
            } catch (Exception ignored) {}
        }
        return null;
    }

    public List<WeightEntry> sortWeights(List<WeightEntry> list, String type) {
        if (list == null || list.isEmpty()) return list;

        switch (type) {
            case "Most Recent":
                list.sort((a, b) -> b.date.compareTo(a.date));
                break;

            case "Oldest":
                list.sort((a, b) -> a.date.compareTo(b.date));
                break;

            case "Highest Weight":
                list.sort((a, b) -> Double.compare(b.weight, a.weight));
                break;

            case "Lowest Weight":
                list.sort((a, b) -> Double.compare(a.weight, b.weight));
                break;
        }

        return list;
    }

    public List<WeightEntry> filterWeights(List<WeightEntry> list, String type) {
        if (list == null || list.isEmpty()) return list;

        List<WeightEntry> filtered = new ArrayList<>();
        Date today = new Date();

        for (WeightEntry e : list) {
            Date entryDate = parseDate(e.date);
            if (entryDate == null) continue;

            long diff = (today.getTime() - entryDate.getTime()) / (1000 * 60 * 60 * 24);

            if (diff < 0) continue;

            if (type.equals("All")) {
                filtered.add(e);
            } else if (type.equals("Last 7 Days") && diff <= 7) {
                filtered.add(e);
            } else if (type.equals("Last 30 Days") && diff <= 30) {
                filtered.add(e);
            }
        }
        return filtered;
    }


}
