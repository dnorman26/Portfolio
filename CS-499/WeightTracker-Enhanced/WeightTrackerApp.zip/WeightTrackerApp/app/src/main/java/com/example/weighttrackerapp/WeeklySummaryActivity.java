package com.example.weighttrackerapp;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.Collections;
import java.util.Comparator;

import android.os.Bundle;
import android.widget.TextView;
import android.database.Cursor;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;
import java.util.Locale;

public class WeeklySummaryActivity extends AppCompatActivity {

    TextView summaryList;
    LineChart weightChart;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weekly_summary);

        summaryList = findViewById(R.id.summaryList);
        weightChart = findViewById(R.id.weightChart);
        db = new DBHelper(this);

        ArrayList<WeightEntry> entries = loadAllWeights();

        List<WeeklySummary> weekly =
                calculateWeeklyAverages(entries);

        displayWeeklyNumbers(weekly);
        setupWeightChart(weekly);
    }

    private ArrayList<WeightEntry> loadAllWeights() {

        ArrayList<WeightEntry> list = new ArrayList<>();

        Cursor cursor = db.getWeights();

        while (cursor.moveToNext()) {

            int id = cursor.getInt(0);
            double weight = cursor.getDouble(1);
            String date = cursor.getString(2);

            list.add(new WeightEntry(id, weight, date));
        }

        cursor.close();

        return list;
    }


    private Date parseDate(String dateStr) {

        if (dateStr == null || dateStr.trim().isEmpty()) {
            return null;
        }

        try {
            SimpleDateFormat sdf =
                    new SimpleDateFormat("MM-dd-yyyy", Locale.US);

            sdf.setLenient(false);

            return sdf.parse(dateStr);

        } catch (Exception e) {
            return null;
        }
    }

    private List<WeeklySummary> calculateWeeklyAverages(
            List<WeightEntry> entries) {

        Map<String, List<Double>> weeklyMap =
                new LinkedHashMap<>();

        for (WeightEntry entry : entries) {

            Date date = parseDate(entry.date);


            if (date == null) {
                continue;
            }

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            int year =
                    calendar.get(Calendar.YEAR);

            int week =
                    calendar.get(Calendar.WEEK_OF_YEAR);

            String weekKey =
                    year + "-W" + week;

            if (!weeklyMap.containsKey(weekKey)) {

                weeklyMap.put(
                        weekKey,
                        new ArrayList<>()
                );
            }

            weeklyMap.get(weekKey).add(entry.weight);
        }

        List<WeeklySummary> summaries =
                new ArrayList<>();

        for (Map.Entry<String, List<Double>> entry
                : weeklyMap.entrySet()) {

            List<Double> weights =
                    entry.getValue();

            double total = 0;

            for (double weight : weights) {
                total += weight;
            }

            double average =
                    total / weights.size();

            summaries.add(
                    new WeeklySummary(
                            entry.getKey(),
                            average
                    )
            );
        }

        return summaries;
    }

    private void displayWeeklyNumbers(
            List<WeeklySummary> weekly) {

        if (weekly == null || weekly.isEmpty()) {

            summaryList.setText(
                    "No weight data available."
            );

            return;
        }

        StringBuilder sb =
                new StringBuilder();

        sb.append("Weekly Average Weight\n\n");

        for (WeeklySummary summary : weekly) {

            String displayWeek =
                    convertWeekToDate(summary.week);

            sb.append(displayWeek)
                    .append("\n")
                    .append("Average: ")
                    .append(
                            String.format(
                                    Locale.US,
                                    "%.1f lbs",
                                    summary.average
                            )
                    )
                    .append("\n\n");
        }

        summaryList.setText(sb.toString());
    }

    private void setupWeightChart(List<WeeklySummary> weekly) {

        if (weekly == null || weekly.isEmpty()) {
            weightChart.clear();
            weightChart.setNoDataText("No weight data for the last 3 months.");
            weightChart.invalidate();
            return;
        }

        List<WeeklySummary> chartData = new ArrayList<>(weekly);


        Collections.sort(chartData, new Comparator<WeeklySummary>() {
            @Override
            public int compare(WeeklySummary a, WeeklySummary b) {
                return getWeekStart(a.week).compareTo(getWeekStart(b.week));
            }
        });

        ArrayList<Entry> entries = new ArrayList<>();
        final ArrayList<String> labels = new ArrayList<>();

        for (int i = 0; i < chartData.size(); i++) {
            WeeklySummary summary = chartData.get(i);

            entries.add(new Entry(i, (float) summary.average));

            labels.add(
                    new SimpleDateFormat("MMM d", Locale.US)
                            .format(getWeekStart(summary.week))
            );
        }

        LineDataSet dataSet = new LineDataSet(
                entries, "Average Weight (lbs)"
        );

        dataSet.setColor(0xFF2196F3);
        dataSet.setCircleColor(0xFF2196F3);
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(4f);
        dataSet.setValueTextSize(10f);
        dataSet.setDrawValues(true);
        dataSet.setMode(LineDataSet.Mode.LINEAR);

        LineData lineData = new LineData(dataSet);
        weightChart.setData(lineData);

        XAxis xAxis = weightChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setLabelRotationAngle(-45f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = Math.round(value);

                if (index >= 0 && index < labels.size()) {
                    return labels.get(index);
                }

                return "";
            }
        });

        weightChart.getAxisRight().setEnabled(false);
        weightChart.getDescription().setEnabled(false);
        weightChart.getLegend().setEnabled(true);
        weightChart.setExtraBottomOffset(15f);
        weightChart.animateX(700);
        weightChart.invalidate();
    }

    private Date getWeekStart(String weekKey) {

        try {
            String[] parts = weekKey.split("-W");

            int year = Integer.parseInt(parts[0]);
            int week = Integer.parseInt(parts[1]);

            Calendar calendar = Calendar.getInstance(Locale.US);
            calendar.clear();
            calendar.setFirstDayOfWeek(Calendar.SUNDAY);
            calendar.setMinimalDaysInFirstWeek(1);
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.WEEK_OF_YEAR, week);
            calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);

            return calendar.getTime();

        } catch (Exception e) {
            return new Date(0);
        }
    }

    private String convertWeekToDate(String weekKey) {

        try {

            String[] parts =
                    weekKey.split("-W");

            int year =
                    Integer.parseInt(parts[0]);

            int week =
                    Integer.parseInt(parts[1]);

            Calendar calendar =
                    Calendar.getInstance();

            calendar.clear();

            calendar.set(
                    Calendar.YEAR,
                    year
            );

            calendar.set(
                    Calendar.WEEK_OF_YEAR,
                    week
            );

            calendar.set(
                    Calendar.DAY_OF_WEEK,
                    Calendar.SUNDAY
            );

            SimpleDateFormat format =
                    new SimpleDateFormat(
                            "MMM d, yyyy",
                            Locale.US
                    );

            return "Week of " +
                    format.format(calendar.getTime());

        } catch (Exception e) {

            return weekKey;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(
                R.menu.main_menu,
                menu
        );

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(
            MenuItem item) {

        if (item.getItemId() ==
                R.id.menu_dashboard) {

            startActivity(
                    new Intent(
                            this,
                            DashboardActivity.class
                    )
            );

            return true;
        }

        if (item.getItemId() ==
                R.id.menu_goal) {

            startActivity(
                    new Intent(
                            this,
                            GoalActivity.class
                    )
            );

            return true;
        }

        if (item.getItemId() ==
                R.id.menu_sms) {

            startActivity(
                    new Intent(
                            this,
                            SmsActivity.class
                    )
            );

            return true;
        }

        if (item.getItemId() ==
                R.id.menu_summary) {

            startActivity(
                    new Intent(
                            this,
                            WeeklySummaryActivity.class
                    )
            );

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

