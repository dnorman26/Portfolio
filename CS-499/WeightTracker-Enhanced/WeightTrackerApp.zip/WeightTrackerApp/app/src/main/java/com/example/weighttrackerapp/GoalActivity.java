package com.example.weighttrackerapp;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;

public class GoalActivity extends AppCompatActivity {

    EditText goalInput;
    Button saveButton;
    TextView goalDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        goalInput = findViewById(R.id.goalInput);
        saveButton = findViewById(R.id.saveGoalButton);
        goalDisplay = findViewById(R.id.currentGoal);

        saveButton.setOnClickListener(v -> {

            String input = goalInput.getText().toString();

            if (input.isEmpty()) {
                Toast.makeText(this, "Enter goal weight", Toast.LENGTH_SHORT).show();
                return;
            }

            double goal = Double.parseDouble(input);


            getSharedPreferences("AppPrefs", MODE_PRIVATE)
                    .edit()
                    .putFloat("goalWeight", (float) goal)
                    .apply();

            goalDisplay.setText("Goal: " + goal + " lbs");
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.menu_dashboard) {
            startActivity(new Intent(this, DashboardActivity.class));
            return true;
        }

        if (item.getItemId() == R.id.menu_sms) {
            startActivity(new Intent(this, SmsActivity.class));
            return true;
        }
        if (item.getItemId() == R.id.menu_summary) {
            startActivity(new Intent(this, WeeklySummaryActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}